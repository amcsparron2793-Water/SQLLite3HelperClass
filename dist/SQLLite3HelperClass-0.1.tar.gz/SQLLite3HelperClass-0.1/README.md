# <u>SQLite3HelperClass</u>
### <i>Makes SQLite3 use quick and easy</i>


SQLite3HelperClass is a quick initialization class that also contains a generic Query class. Basic SQLite3 connections are easy. This class is meant to be subclassed and expanded as needed.
